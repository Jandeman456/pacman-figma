# Pacman Figma Game

A simple Pacman game in React + TypeScript, using your custom images for Pacman, Ghost, Points, and Pill.

## How to Run Locally

1. **Install dependencies:**
   ```
   npm install
   ```

2. **Start the game:**
   ```
   npm start
   ```

3. Open http://localhost:3000 in your browser and play!

## Deploy Online

You can deploy the repo to [Netlify](https://www.netlify.com/) or [Vercel](https://vercel.com/) for a live preview.

### Deploying to Netlify

1. Push your code to GitHub (or any Git provider).
2. Go to [Netlify](https://app.netlify.com/) and click **Add new site > Import an existing project**.
3. Connect your repo and use:
   - **Build Command:** `npm run build`
   - **Publish Directory:** `build`

That's it! Netlify will build and deploy your site. You get a live link to share.

---

Enjoy your custom Pacman!