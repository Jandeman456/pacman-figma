import React, { useState, useEffect, useCallback } from "react";
import "./App.css";
import { LEVELS, TILE_SIZE, TILES } from "./gameData";

type Position = { x: number, y: number };
type Direction = "up" | "down" | "left" | "right" | null;

const directions: Record<string, Position> = {
  up: { x: 0, y: -1 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
  right: { x: 1, y: 0 }
};

function getInitialGhosts(level: number) {
  const levelData = LEVELS[level];
  return levelData.ghosts.map((g: any) => ({
    ...g,
    dir: "left" as Direction,
    weak: false
  }));
}

function App() {
  const [level, setLevel] = useState(0);
  const [map, setMap] = useState(JSON.parse(JSON.stringify(LEVELS[0].map)));
  const [pacman, setPacman] = useState({ ...LEVELS[0].pacman, dir: null as Direction });
  const [ghosts, setGhosts] = useState(getInitialGhosts(0));
  const [score, setScore] = useState(0);
  const [pillActive, setPillActive] = useState(false);
  const [pillTimer, setPillTimer] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let dir: Direction = null;
      switch (e.key) {
        case "ArrowUp":
        case "w": dir = "up"; break;
        case "ArrowDown":
        case "s": dir = "down"; break;
        case "ArrowLeft":
        case "a": dir = "left"; break;
        case "ArrowRight":
        case "d": dir = "right"; break;
        default: break;
      }
      if (dir) setPacman(p => ({ ...p, dir }));
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    if (gameOver || won) return;
    const interval = setInterval(() => {
      setPacman(p => {
        if (!p.dir) return p;
        const { x, y } = p;
        const nx = x + directions[p.dir].x;
        const ny = y + directions[p.dir].y;
        if (map[ny] && map[ny][nx] !== TILES.wall) {
          let newMap = map.map((row: number[]) => [...row]);
          if (newMap[ny][nx] === TILES.point) {
            newMap[ny][nx] = TILES.floor;
            setScore(s => s + 10);
          }
          if (newMap[ny][nx] === TILES.pill) {
            newMap[ny][nx] = TILES.floor;
            setScore(s => s + 50);
            setPillActive(true);
            setPillTimer(60);
            setGhosts(gs => gs.map(g => ({ ...g, weak: true })));
          }
          setMap(newMap);

          if (!newMap.some((row: number[]) => row.includes(TILES.point) || row.includes(TILES.pill))) {
            setWon(true);
          }

          return { ...p, x: nx, y: ny };
        }
        return p;
      });

      setGhosts(gs => gs.map(g => {
        let { x, y, dir, weak } = g;
        const possibleDirs: Direction[] = ["up", "down", "left", "right"].filter(d => {
          const nx = x + directions[d].x;
          const ny = y + directions[d].y;
          return map[ny] && map[ny][nx] !== TILES.wall;
        }) as Direction[];
        let newDir = dir;
        if (!possibleDirs.includes(dir || "")) {
          newDir = possibleDirs[Math.floor(Math.random() * possibleDirs.length)];
        }
        const nx = x + (newDir ? directions[newDir].x : 0);
        const ny = y + (newDir ? directions[newDir].y : 0);
        if (map[ny] && map[ny][nx] !== TILES.wall) {
          return { ...g, x: nx, y: ny, dir: newDir };
        } else {
          return { ...g, dir: possibleDirs[Math.floor(Math.random() * possibleDirs.length)] };
        }
      }));

      if (pillActive) {
        setPillTimer(t => {
          if (t <= 1) {
            setPillActive(false);
            setGhosts(gs => gs.map(g => ({ ...g, weak: false })));
            return 0;
          }
          return t - 1;
        });
      }

      ghosts.forEach(g => {
        if (g.x === pacman.x && g.y === pacman.y) {
          if (g.weak) {
            setScore(s => s + 200);
            setGhosts(gs => gs.map(gg => gg === g ? { ...gg, x: LEVELS[level].ghosts[0].x, y: LEVELS[level].ghosts[0].y, weak: false } : gg));
          } else {
            setGameOver(true);
          }
        }
      });
    }, 150);
    return () => clearInterval(interval);
  }, [pacman, map, ghosts, pillActive, gameOver, won, level]);

  const nextLevel = useCallback(() => {
    if (level + 1 < LEVELS.length) {
      setLevel(l => l + 1);
      setMap(JSON.parse(JSON.stringify(LEVELS[level + 1].map)));
      setPacman({ ...LEVELS[level + 1].pacman, dir: null });
      setGhosts(getInitialGhosts(level + 1));
      setGameOver(false);
      setWon(false);
      setScore(0);
    }
  }, [level]);

  return (
    <div className="App">
      <h1>Pacman Figma Clone</h1>
      <div>Score: {score}</div>
      {gameOver && <div className="message">Game Over</div>}
      {won && (
        <div className="message">
          You Win!
          {level + 1 < LEVELS.length && (
            <button onClick={nextLevel}>Next Level</button>
          )}
        </div>
      )}
      <div 
        className="board"
        style={{ width: TILE_SIZE * map[0].length, height: TILE_SIZE * map.length }}
      >
        {map.map((row: number[], y: number) =>
          row.map((cell: number, x: number) => {
            let key = `${x}-${y}`;
            let content = null;
            if (cell === TILES.wall) content = <div className="wall" />;
            else if (cell === TILES.point) content = <div className="point" />;
            else if (cell === TILES.pill) content = <div className="pill" />;
            return <div key={key} className="cell">{content}</div>;
          })
        )}
        {/* Pacman */}
        <div
          className="pacman"
          style={{ left: pacman.x * TILE_SIZE, top: pacman.y * TILE_SIZE }}
        />
        {/* Ghosts */}
        {ghosts.map((g, idx) => (
          <div
            key={idx}
            className={`ghost${g.weak ? " weak" : ""}`}
            style={{ left: g.x * TILE_SIZE, top: g.y * TILE_SIZE }}
          />
        ))}
      </div>
      <div style={{ marginTop: 16 }}>
        <button onClick={() => window.location.reload()}>Restart</button>
      </div>
    </div>
  );
}

export default App;